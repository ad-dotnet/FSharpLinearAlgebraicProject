﻿namespace FSharp25LinearAlgebraFunctions
open MathNet.Numerics.LinearAlgebra

type LinearAlgebraFunctions_Inverse() =

    // 1. Standard Least Squares
    static member f1_StandardLeastSquares
        (X: Matrix<double>, y: Vector<double>, b: byref<Vector<double>>)
        : Vector<double> =

        b <- (X.Transpose() * X).Inverse() * X.Transpose() * y
        b

    // 2. Generalized Least Squares
    static member f2_GeneralizedLeastSquares
        (X: Matrix<double>, M: Matrix<double>, y: Vector<double>, b: byref<Vector<double>>)
        : Vector<double> =

        b <- (X.Transpose() * M.Inverse() * X).Inverse() * X.Transpose() * M.Inverse() * y
        b

    // 3. Optimization [73]
    static member f3_Optimization1
        (A: Matrix<double>, W: Matrix<double>, b: Vector<double>, c: Vector<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- W * (A.Transpose() * (A * W * A.Transpose()).Inverse() * b - c)
        x

    // 4. Optimization [73] - returns both (xf, xo)
    static member f4_Optimization2
        (A: Matrix<double>, W: Matrix<double>, b: Vector<double>, c: Vector<double>,
         x: Vector<double>, xf: byref<Vector<double>>, xo: byref<Vector<double>>)
        : struct (Vector<double> * Vector<double>) =

        xf <- W * A.Transpose() * (A * W * A.Transpose()).Inverse() * (b - A * x)
        xo <- W * (A.Transpose() * (A * W * A.Transpose()).Inverse() * A * x - c)
        struct (xf, xo)

    // 5. Signal Processing [21]
    static member f5_SignalProcessing
        (A: Matrix<double>, B: Matrix<double>, R: Matrix<double>, L: Matrix<double>,
         y: Vector<double>, I: Matrix<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- (A.Transpose().Inverse() * B.Transpose() * B * A.Inverse() + R.Transpose() * L * R).Inverse() * A.Transpose().Inverse() * B.Transpose() * B * A.Inverse() * y
        x

    // 6. Triangular Matrix Inversion [14]
    static member f6_TriangularMatrixInversion
        (L00: Matrix<double>, L11: Matrix<double>, L22: Matrix<double>,
         L10: Matrix<double>, L20: Matrix<double>, L21: Matrix<double>,
         I00: Matrix<double>, I11: Matrix<double>,
         x10: byref<Matrix<double>>, x20: byref<Matrix<double>>,
         x11: byref<Matrix<double>>, x21: byref<Matrix<double>>)
        : struct (Matrix<double> * Matrix<double> * Matrix<double> * Matrix<double>) =

        x10 <- L10 * L00.Inverse() * I00
        x20 <- L20 + L22.Inverse() * L21 * L11.Inverse() * L10
        x11 <- L11.Inverse() * I11
        x21 <- -(L22.Inverse()) * L21
        struct (x10, x20, x11, x21)

    // 7. Ensemble Kalman Filter [59]
    static member f7_EnsembleKalmanFilter
        (Xb: Matrix<double>, B: Matrix<double>, H: Matrix<double>, R: Matrix<double>,
         Y: Matrix<double>, IB: Matrix<double>, xa: byref<Matrix<double>>)
        : Matrix<double> =

        xa <- Xb + (B.Inverse() * IB + H.Transpose() * R.Inverse() * H).Inverse() * H.Transpose() * R.Inverse() * (Y - H * Xb)
        xa

    // 8. Ensemble Kalman Filter [59]
    static member f8_EnsembleKalmanFilterDeltaX
        (B: Matrix<double>, H: Matrix<double>, R: Matrix<double>, Y: Matrix<double>,
         Xb: Matrix<double>, IB: Matrix<double>, deltaX: byref<Matrix<double>>)
        : Matrix<double> =

        deltaX <- (B.Inverse() * IB + H.Transpose() * R.Inverse() * H).Inverse() * H.Transpose() * R.Inverse() * (Y - H * Xb)
        deltaX

    // 9. Ensemble Kalman Filter Variant [59]
    static member f9_EnsembleKalmanFilterDeltaXVariant
        (X: Matrix<double>, V: Matrix<double>, R: Matrix<double>, H: Matrix<double>,
         Y: Matrix<double>, Xb: Matrix<double>, deltaX: byref<Matrix<double>>)
        : Matrix<double> =

        deltaX <- X * V.Transpose() * (R + H * X * (H * X).Transpose()).Inverse() * (Y - H * Xb)
        deltaX

    // 10. Image Restoration [74]
    static member f10_ImageRestoration
        (H: Matrix<double>, y: Vector<double>, vk_1: Vector<double>, uk_1: Vector<double>,
         lambda: double, sigma: double, I: Matrix<double>, xk: byref<Vector<double>>)
        : Vector<double> =

        xk <- (H.Transpose() * H + lambda * sigma * sigma * I).Inverse() * (H.Transpose() * y + lambda * sigma * sigma * (vk_1 - uk_1))
        xk

    // 11. Image Restoration [74]
    static member f11_ImageRestoration
        (H: Matrix<double>, y: Vector<double>, xk: Vector<double>,
         Im: Matrix<double>, In: Matrix<double>, yk: byref<Vector<double>>)
        : Vector<double> =

        let Hdagger = H.Transpose() * (H * H.Transpose()).Inverse() * Im
        yk <- Hdagger * y + (In - Hdagger * H) * xk
        yk

    // 12. Randomized Matrix Inversion [41]
    static member f12_RandomizedMatrixInversion
        (A: Matrix<double>, W: Matrix<double>, S: Matrix<double>, Xk: Matrix<double>,
         I: Matrix<double>, xk1: byref<Matrix<double>>)
        : Matrix<double> =

        xk1 <- Xk + W * A.Transpose() * S * (S.Transpose() * A * W * A.Transpose() * S).Inverse() * S.Transpose() * (I - A * Xk)
        xk1

    // 13. Randomized Matrix Inversion [41]
    static member f13_RandomizedMatrixInversion
        (A: Matrix<double>, W: Matrix<double>, S: Matrix<double>, Xk: Matrix<double>,
         I: Matrix<double>, xk1: byref<Matrix<double>>)
        : Matrix<double> =

        let Lambda = S * (S.Transpose() * A.Transpose() * W * A * S).Inverse() * S.Transpose()
        xk1 <- Xk + (I - Xk * A.Transpose()) * Lambda * A.Transpose() * W
        xk1

    // 14. Randomized Matrix Inversion [41]
    static member f14_RandomizedMatrixInversion
        (A: Matrix<double>, W: Matrix<double>, S: Matrix<double>, Xk: Matrix<double>,
         I: Matrix<double>, xk1: byref<Matrix<double>>)
        : Matrix<double> =

        let Lambda = S * (S.Transpose() * A * W * A * S).Inverse() * S.Transpose()
        let Theta = Lambda * A * W
        let Mk = Xk * A - I
        xk1 <- Xk - Mk * Theta - (Mk * Theta).Transpose() + Theta.Transpose() * (A * Xk * A - A) * Theta
        xk1

    // 15. Randomized Matrix Inversion [41]
    static member f15_RandomizedMatrixInversion
        (A: Matrix<double>, S: Matrix<double>, Xk: Matrix<double>,
         I: Matrix<double>, xk1: byref<Matrix<double>>)
        : Matrix<double> =

        let ASinv = (S.Transpose() * A * S).Inverse() * S.Transpose()
        xk1 <- S * ASinv + (I - S * ASinv * A) * Xk * (I - A * S * ASinv)
        xk1

    // 16. Stochastic Newton [19]
    static member f16_StochasticNewton
        (k: double, Bk_1: Matrix<double>, A: Matrix<double>, Wk: Matrix<double>,
         Il: Matrix<double>, In: Matrix<double>, bk: byref<Matrix<double>>)
        : Matrix<double> =

        bk <- (k / (k - 1.0)) * Bk_1 * (In - A.Transpose() * Wk * ((k - 1.0) * Il + Wk.Transpose() * A * Bk_1 * A.Transpose() * Wk).Inverse() * Wk.Transpose() * A * Bk_1)
        bk

    // 17. Stochastic Newton [19]
    static member f17_StochasticNewton
        (A: Matrix<double>, W1: Matrix<double>, lambda1: double,
         In: Matrix<double>, Il: Matrix<double>, b1: byref<Matrix<double>>)
        : Matrix<double> =

        b1 <- (1.0 / lambda1) * (In - A.Transpose() * W1 * (lambda1 * Il + W1.Transpose() * A * A.Transpose() * W1).Inverse() * W1.Transpose() * A)
        b1

    // 18. Tikhonov Regularization [37]
    static member f18_TikhonovRegularization
        (A: Matrix<double>, Gamma: Matrix<double>, b: Vector<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- (A.Transpose() * A + Gamma.Transpose() * Gamma).Inverse() * A.Transpose() * b
        x

    // 19. Tikhonov Regularization [37]
    static member f19_TikhonovRegularization
        (A: Matrix<double>, alpha: double, I: Matrix<double>, b: Vector<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- (A.Transpose() * A + alpha * alpha * I).Inverse() * A.Transpose() * b
        x

    // 20. Generalized Tikhonov Regularization
    static member f20_GeneralizedTikhonov
        (A: Matrix<double>, P: Matrix<double>, Q: Matrix<double>, b: Vector<double>,
         x0: Vector<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- (A.Transpose() * P * A + Q).Inverse() * (A.Transpose() * P * b + Q * x0)
        x

    // 21. Generalized Tikhonov Regularization
    static member f21_GeneralizedTikhonov
        (A: Matrix<double>, P: Matrix<double>, Q: Matrix<double>, b: Vector<double>,
         x0: Vector<double>, x: byref<Vector<double>>)
        : Vector<double> =

        x <- x0 + (A.Transpose() * P * A + Q).Inverse() * A.Transpose() * P * (b - A * x0)
        x

    // 22. LMMSE Estimator [52]
    static member f22_LMMSEEstimator
        (A: Matrix<double>, CX: Matrix<double>, CZ: Matrix<double>, y: Vector<double>,
         x: Vector<double>, xout: byref<Vector<double>>)
        : Vector<double> =

        xout <- CX * A.Transpose() * (A * CX * A.Transpose() + CZ).Inverse() * (y - A * x) + x
        xout

    // 23. LMMSE Estimator [52]
    static member f23_LMMSEEstimator2
        (A: Matrix<double>, CX: Matrix<double>, CZ: Matrix<double>, y: Vector<double>,
         x: Vector<double>, xout: byref<Vector<double>>)
        : Vector<double> =

        xout <- (A.Transpose() * CZ.Inverse() * A + CX.Inverse()).Inverse() * A.Transpose() * CZ.Inverse() * (y - A * x) + x
        xout

    // 24. LMMSE Estimator [52]
    static member f24_LMMSEEstimator3
        (A: Matrix<double>, Ct: Matrix<double>, CZ: Matrix<double>, xt: Vector<double>,
         y: Vector<double>, I_m: Matrix<double>, I_n: Matrix<double>,
         kt1: byref<Matrix<double>>, xt1: byref<Vector<double>>, ct1: byref<Matrix<double>>)
        : struct (Matrix<double> * Vector<double> * Matrix<double>) =

        kt1 <- Ct * A.Transpose() * (A * Ct * A.Transpose() + CZ).Inverse() * I_m
        xt1 <- xt + kt1 * (y - A * xt)
        ct1 <- (I_n - kt1 * A) * Ct
        struct (kt1, xt1, ct1)

    // 25. Kalman Filter [53]
    static member f25_KalmanFilter
        (Pk_1: Matrix<double>, Hk: Matrix<double>, Rk: Matrix<double>,
         xk_1: Vector<double>, zk: Vector<double>, I_n: Matrix<double>, I_m: Matrix<double>,
         kk: byref<Matrix<double>>, pk: byref<Matrix<double>>, xk: byref<Vector<double>>)
        : struct (Matrix<double> * Matrix<double> * Vector<double>) =

        kk <- Pk_1 * Hk.Transpose() * (Hk * Pk_1 * Hk.Transpose() + Rk).Inverse() * I_m
        pk <- (I_n - kk * Hk) * Pk_1
        xk <- xk_1 + kk * (zk - Hk * xk_1)
        struct (kk, pk, xk)
